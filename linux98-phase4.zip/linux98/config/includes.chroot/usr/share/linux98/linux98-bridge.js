/**
 * Linux 98 - System Bridge Layer
 * Connects the HTML desktop UI to real Linux system calls.
 * 
 * This file is injected by linux98-desktop (Python/GTK) via WebKit.
 * When running in a browser (development), calls are simulated.
 *
 * Usage in desktop.html:
 *   linux98.openTerminal()
 *   linux98.exec('ls /home', result => console.log(result))
 *   linux98.sysinfo(info => updateAboutBox(info))
 *   linux98.listDir('/home/user', entries => renderFiles(entries))
 *   linux98.shutdown()
 *   linux98.reboot()
 */

(function() {
  'use strict';

  const isRealOS = typeof window.webkit !== 'undefined' &&
                   typeof window.webkit.messageHandlers !== 'undefined';

  const callbacks = {};

  // Called by Python to return results
  window.__linux98_return = function(id, result) {
    if (callbacks[id]) {
      callbacks[id](result);
      delete callbacks[id];
    }
  };

  function send(data, cb) {
    const id = Date.now() + Math.random();
    data.id = id;
    if (cb) callbacks[id] = cb;
    if (isRealOS) {
      window.webkit.messageHandlers.linux98.postMessage(JSON.stringify(data));
    } else {
      // Simulate in browser for development
      setTimeout(() => simulateResponse(data, cb), 50);
    }
  }

  function simulateResponse(data, cb) {
    if (!cb) return;
    switch (data.type) {
      case 'exec':
        cb(`[simulated] $ ${data.cmd}\nCommand output here`);
        break;
      case 'sysinfo':
        window.__linux98_sysinfo = {
          kernel: '6.1.0-linux98',
          cpu: 'Intel Core i5 (simulated)',
          ram_total_mb: 4096,
          ram_used_mb: 1024,
          ram_free_mb: 3072,
          disk_total_gb: 32.0,
          disk_free_gb: 18.5
        };
        if (cb) cb(window.__linux98_sysinfo);
        break;
      case 'listdir':
        cb([
          { name: 'Desktop',   isDir: true,  size: 0 },
          { name: 'Documents', isDir: true,  size: 0 },
          { name: 'Downloads', isDir: true,  size: 0 },
          { name: 'notes.txt', isDir: false, size: 1024 },
        ]);
        break;
      case 'terminal':
        console.log('[Simulated] Open terminal');
        break;
    }
  }

  window.linux98 = {
    /** Open a real xterm terminal window */
    openTerminal() { send({ type: 'terminal' }); },

    /** Run a shell command, get output in callback */
    exec(cmd, cb) { send({ type: 'exec', cmd }, cb); },

    /** Get system info object */
    sysinfo(cb) { send({ type: 'sysinfo' }, cb); },

    /** List directory contents */
    listDir(path, cb) { send({ type: 'listdir', path }, cb); },

    /** Shutdown the system */
    shutdown() {
      if (confirm('Shut down Linux 98?')) send({ type: 'shutdown' });
    },

    /** Reboot the system */
    reboot() {
      if (confirm('Restart Linux 98?')) send({ type: 'reboot' });
    },

    /** Open a Linux98 app by name */
    openApp(name) {
      send({ type: 'exec', cmd: `linux98-${name} &` });
    },

    /** Check if running as real OS */
    isRealOS: isRealOS
  };

  console.log(`[Linux98 Bridge] ${isRealOS ? 'Real OS mode' : 'Browser simulation mode'}`);
})();
