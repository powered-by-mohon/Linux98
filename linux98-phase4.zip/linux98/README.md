# Linux 98
**A real Linux distro with a Windows 98-style desktop**

Built on Debian Live, powered by Linux kernel, with a custom X11 desktop environment.

---

## Project Structure

```
linux98/
├── build/              ← Build scripts
│   ├── build.sh        ← Main build script
│   └── clean.sh        ← Clean build artifacts
├── config/             ← live-build config
│   ├── packages/       ← Package lists
│   ├── hooks/          ← Build hooks (run during build)
│   └── includes.chroot/← Files copied into the ISO
│       ├── etc/linux98/         ← System config
│       ├── usr/share/linux98/   ← Desktop assets (HTML UI)
│       └── usr/bin/             ← Custom executables
├── desktop-src/        ← Source code for WM and apps
└── docs/               ← Documentation
```

---

## Architecture

```
Linux Kernel (6.x)
  └── systemd
      └── X.Org (X11)
          └── openbox (WM base) + linux98-wm (our theme layer)
              ├── linux98-desktop   (the HTML-based desktop via webview)
              ├── linux98-terminal  (xterm with Win98 theme)
              ├── linux98-files     (file manager)
              └── linux98-panel     (taskbar)
```

---

## Build Requirements (on your build machine)

```bash
sudo apt install live-build debootstrap xorriso isolinux
```

## Build Steps

```bash
cd linux98/build
chmod +x build.sh
sudo ./build.sh
```

Output: `linux98.iso` (~800MB)

---

## Phases

- [x] Phase 1 — Base system + bootable ISO structure
- [ ] Phase 2 — Custom X11 Window Manager (Win98 look)
- [ ] Phase 3 — Apps: Terminal, File Manager, Notepad, Control Panel
- [ ] Phase 4 — Installer (like Ubuntu installer)

---

## Phase 2 — Custom Window Manager ✅

فایل‌های فاز ۲:

- `wm/linux98-wm` — WM اصلی (Python + Xlib)
- `wm/linux98-start-menu` — پنجره Start Menu (GTK)
- `config/hooks/0200-linux98-wm.hook.chroot` — نصب WM در ISO
- `config/packages/02-wm.list.chroot` — پکیج‌های فاز ۲

### معماری WM

```
linux98-wm (Python/Xlib)
  ├── ManagedWindow — هر پنجره رو می‌گیره و frame اضافه می‌کنه
  │   ├── frame      — border + titlebar
  │   ├── btn_close  — دکمه X
  │   ├── btn_max    — دکمه □
  │   └── btn_min    — دکمه _
  ├── Taskbar — نوار پایین با Start + window buttons + clock
  └── Event Loop — همه event های X11 رو هندل می‌کنه
```
