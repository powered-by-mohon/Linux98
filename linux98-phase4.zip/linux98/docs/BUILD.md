# Linux 98 — Build & Development Guide

## چیه؟

یه Linux distro واقعی با:
- **هسته:** Linux 6.x (Debian bookworm)
- **دسکتاپ:** HTML/JS UI داخل GTK WebView (همون ظاهر Win98)
- **WM:** Openbox با تم Win98
- **بوتابل:** ISO قابل نصب روی هر کامپیوتر

---

## ساختار فایل‌ها

```
linux98/
├── README.md
├── build/
│   ├── build.sh          ← اجرا کن برای ساخت ISO
│   └── clean.sh          ← پاک کردن build قبلی
├── config/
│   ├── packages/
│   │   └── 01-base.list.chroot   ← لیست پکیج‌ها
│   ├── hooks/
│   │   └── 0100-linux98-setup.hook.chroot  ← تنظیمات محیط
│   └── includes.chroot/
│       ├── usr/bin/
│       │   └── linux98-desktop   ← برنامه اصلی دسکتاپ (Python)
│       ├── usr/share/linux98/
│       │   ├── desktop.html      ← UI دسکتاپ (همون فایل اصلی‌ات)
│       │   └── linux98-bridge.js ← اتصال JS به سیستم
│       └── etc/linux98/
│           └── linux98-desktop.service
└── docs/
    └── BUILD.md   ← این فایل
```

---

## پیش‌نیازها (روی ماشین build)

باید Debian یا Ubuntu داشته باشی:

```bash
sudo apt update
sudo apt install live-build debootstrap xorriso isolinux squashfs-tools
```

---

## ساخت ISO

```bash
cd linux98/build
chmod +x build.sh clean.sh
sudo ./build.sh
```

**مدت زمان:** ۱۰ تا ۳۰ دقیقه (بستگی به سرعت اینترنت)  
**خروجی:** `linux98.iso` (~600-900MB)

---

## فلش کردن روی USB

```bash
# پیدا کردن USB
lsblk

# فلش کردن (sdX رو عوض کن)
sudo dd if=linux98.iso of=/dev/sdX bs=4M status=progress
sync
```

یا از **Balena Etcher** استفاده کن (گرافیکی).

---

## تست در VirtualBox / QEMU

### VirtualBox
1. New VM → Linux → Debian 64-bit
2. RAM: حداقل 2GB
3. Mount ISO → Boot

### QEMU (سریع‌تر)
```bash
qemu-system-x86_64 \
  -cdrom linux98.iso \
  -m 2G \
  -enable-kvm \
  -vga virtio \
  -display gtk
```

---

## معماری دسکتاپ

```
X11 (Xorg)
  └── Openbox (Window Manager)
      ├── linux98-desktop (Python/GTK + WebKit)
      │   └── desktop.html (HTML/JS UI)
      │       └── linux98-bridge.js (JS ↔ Python IPC)
      └── xterm (terminal instances)
```

### چطور HTML با لینوکس ارتباط داره

وقتی کاربر توی دسکتاپ روی "Terminal" کلیک می‌کنه:

```
HTML → linux98.openTerminal()
     → window.webkit.messageHandlers.linux98.postMessage(...)
     → Python receives message
     → subprocess.Popen(['xterm', ...])
     → xterm window opens
```

---

## فاز بعدی: Custom Window Manager

به جای Openbox، می‌شه یه WM سفارشی با Python/C نوشت که:
- تایتل‌بار کاملاً Win98 باشه
- دکمه‌های Start/Min/Max عین Win98
- بدون نیاز به Openbox

**ابزار:** `python3-xlib` یا C با `Xlib.h`

---

## Roadmap

| فاز | وضعیت | توضیح |
|-----|--------|-------|
| 1 - Base System | ✅ آماده | Debian + X11 + HTML Desktop |
| 2 - Custom WM | 🔜 بعدی | Win98 titlebar کامل با C/Python |
| 3 - Apps | 🔜 | Terminal, Files, Notepad واقعی |
| 4 - Installer | 🔜 | مثل Ubuntu installer |
| 5 - Package Manager | 🔜 | GUI برای apt |
